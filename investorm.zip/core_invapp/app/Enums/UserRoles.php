<?php


namespace App\Enums;

interface UserRoles
{
    const SUPER_ADMIN = 'super-admin';
    const ADMIN = 'admin';
    const USER = 'user';
}
