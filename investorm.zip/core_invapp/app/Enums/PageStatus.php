<?php


namespace App\Enums;

interface PageStatus
{
    const ACTIVE = 'active';
    const INACTIVE = 'inactive';
}
