<?php


namespace App\Enums;

interface ExchangeRateUpdateType
{
    const AUTOMATIC = 'automatic';
    const MANUAL = 'manual';
}
