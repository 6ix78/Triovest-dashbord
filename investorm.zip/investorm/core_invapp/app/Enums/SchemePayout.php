<?php


namespace App\Enums;

interface SchemePayout
{
    const TERM_BASIS = 'term_basis';
    const AFTER_MATURED = 'after_matured';
}
