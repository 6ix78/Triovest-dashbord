<?php


namespace App\Enums;

interface CurrencyType
{
    const FIAT = 'fiat';
    const CRYPTO = 'crypto';
}
