<?php


namespace App\Enums;

interface PaymentMethodStatus
{
    const ACTIVE = 'active';
    const INACTIVE = 'inactive';
}
